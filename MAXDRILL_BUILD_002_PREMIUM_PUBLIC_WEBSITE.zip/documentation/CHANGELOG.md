# CHANGELOG

## BUILD 002
- Rebuilt all public corporate pages.
- Added trust, research, Academy and responsibility content.
- Added newsletter interest flow.
- Added essential-cookie notice.
- Added security headers.
- Removed temporary Build 001B marker.

## BUILD 001B
- Corrected public version labels and cache.
