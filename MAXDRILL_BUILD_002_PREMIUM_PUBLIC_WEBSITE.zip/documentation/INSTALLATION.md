# INSTALLATION

1. Extract the ZIP.
2. Open the `website` folder.
3. Copy everything inside it.
4. Paste into your local `maxdrill-website` repository.
5. Replace all existing files.
6. In GitHub Desktop commit:
   `Launch MAXDRILL Public Build 002`
7. Click **Push origin**.
8. Wait for Cloudflare Pages.
9. Open `https://maxdrilltech.com/?build=002`
10. Press **Ctrl + F5**.

Check:
- Home
- Company
- Decision Intelligence
- Research
- Academy
- Responsibility
- Contact

Internal routes such as `/store/` must remain masked.
