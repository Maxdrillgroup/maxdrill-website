# ROADMAP

- Public Build 001B — completed
- Public Build 002 — completed
- Internal Build 003 — Genesis ecosystem
- Internal Build 004 — Academy
- Internal Build 005 — Client platform
- Internal Build 006 — Secure commerce and licensing
- Platform 1.0 — official launch
