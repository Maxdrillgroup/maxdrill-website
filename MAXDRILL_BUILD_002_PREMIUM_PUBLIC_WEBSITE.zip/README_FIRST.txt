MAXDRILL PUBLIC BUILD 002

This ZIP is for the live public website.

Open:
documentation/INSTALLATION.md
